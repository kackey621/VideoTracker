<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_hlsplayer';
$plugin->version = 2025042305;
$plugin->requires = 2024100700; // Moodle 4.5+ or 5.0 base
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = 'v0.1.0';
